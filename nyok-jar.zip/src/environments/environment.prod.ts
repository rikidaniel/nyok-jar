

export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyAIHYNQJZqYbR8arv5_WqKE99SW-NYqq3A",
    authDomain: "nyokjar2.firebaseapp.com",
    projectId: "nyokjar2",
    storageBucket: "nyokjar2.firebasestorage.app",
    messagingSenderId: "199554869322",
    appId: "1:199554869322:web:4f7bbbd25d101195bc5eb3",
    measurementId: "G-QKZGRC6MQV"
  },

  geminiApiKey: 'AIzaSyDsQoDiG29P9Xe99m-UztF6DsnCDVDUG30'
}


