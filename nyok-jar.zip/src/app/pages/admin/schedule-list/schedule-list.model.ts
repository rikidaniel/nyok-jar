export interface ScheduleListModel {
  id: string;
  date: string;
  email: string;
  name: string;
  time: string;
  createdAt: string;

}
