export enum PackageEnum {
  Basic = 150000,
  Standard = 300000

}
