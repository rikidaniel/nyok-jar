export enum UserStatusEnum{
  Active = 'active',
  Inactive = 'inactive',
  Blocked = 'blocked',

}
