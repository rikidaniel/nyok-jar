export enum UserRoleEnum{
  Admin = 'admin',
  User = 'user',
}
