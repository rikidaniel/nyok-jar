export interface PaymentAmount {
  id: string;
  paymentAmount: number;
}
