export interface ExpenseAmount {
  id: string;
  expenseAmount: number;
}
