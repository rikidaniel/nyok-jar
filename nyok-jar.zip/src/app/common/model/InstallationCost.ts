export interface InstallationCost {
  id: string;
  installationCost: number;
}
