export interface RegistrationDate {
  id: string;
  registrationDate: any; // You can replace `any` with the correct Firestore Timestamp type if available
}
